# lc-flekjit-kit — put FlekJIT (built-in JIT) into your LiveContainer fork

Turns upstream LiveContainer (main @ b0f53e8, v3.8.14) into your own fork in
which the built-in FlekJIT enabler from FlekDeck v0.3.0 works — pairing-file
JIT, no server, no other apps — **with no Premium anywhere**: the port carries
only the enabler stack, not FlekStore's subscription machinery. Upstream's own
SideStore-certificate button, store-variable entitlements and nightly CI stay
as upstream built them.

## What is in the kit

```
lc-flekjit-kit/
├── README.md                                  <- this file
├── .github/workflows/build-flekjit.yml        <- the CI workflow (commit it as-is)
├── .github/flekjit/entitlements-{app,vpn}.xml <- ldid entitlements used by CI
├── patches/
│   ├── flekjit-core.patch      <- launch chain: LCBootstrap enabler + enum case + adopt
│   ├── flekjit-ui.patch        <- the whole Settings → JIT page + pairing/report/shortcut
│   ├── flekjit-vpn.patch       <- the built-in LoopbackVPN (optional but included)
│   └── flekjit-project.patch   <- StikJITHeadless + LoopbackVPN targets in the pbxproj
└── vendored/                                  <- commit these two dirs into the fork too:
    ├── StikJITHeadless/  (sources + StikJIT.xcframework, ~3 MB)
    └── IdevicePairing/   (IdevicePairing.dylib, ~2 MB, + build.sh)
```

## Setup (4 commands after forking)

1. Fork https://github.com/LiveContainer/LiveContainer and make the fork private.
2. Clone your fork locally, then from this kit copy **everything** into it:
   ```sh
   cp -R patches/ vendored/ .github/ /your-fork/   # .github merges with the existing one
   git add -A && git commit -m "FlekJIT fork kit"
   ```
3. Push. In your fork on GitHub: **Actions → Build FlekJIT fork → Run workflow**.
4. When the run goes green (~20-40 min), the Artifacts panel holds **two** IPAs:
   - **LiveContainer-flekjit.ipa** — the plain fork; sideload with SideStore/AltStore
     exactly like upstream's IPA.
   - **LiveContainer-flekjit+SideStore.ipa** — the LC+SideStore build (upstream's
     `+SideStore` packaging): a full SideStore nightly is embedded as
     `SideStoreApp.framework`, so LiveContainer can pull free 7-day certs by
     itself (Settings toggle "Open SideStore" / the builtinSideStore app).
     Use this one if you want the all-in-one.

That is all. The workflow applies the patches at build time when your fork is
still pristine upstream, and detects an already-patched fork and skips them —
so committing the patches (not the patched sources) is the supported layout.
The +SideStore step needs nothing extra from you: it downloads the SideStore
nightly and the dylibify tool at build time, exactly like upstream's own CI.

## On the device

1. Settings → JIT → enabler **Built-in (FlekJIT port)**; a fresh install adopts it alone.
2. Pairing file: import one made with FlekPair/iloader/idevice_pair, or make one
   **on-device** (iOS 27+: Settings → Privacy & Security → Developer Mode lists
   this app as a pairing host).
3. VPN: free signing has no NE entitlement → the page routes through
   **LocalDevVPN** (App Store). Paid dev account or TrollStore → built-in
   LoopbackVPN / JIT from install.
4. Hold an app icon → **Settings → Launch with JIT**; JIT comes on at launch.

## Upgrading

When upstream moves: sync the fork, re-run. Each patch is gated on a file (or
marker line) only that patch creates, so an already-patched fork skips cleanly.
If your own commits shifted the hunk contexts, the patch step falls back to a
3-way merge (`fetch-depth: 0` gives it the blob data it needs) and then two
gates protect the build: a conflict-marker sweep and `plutil -lint` on
`project.pbxproj` — a corrupted project file now fails the run **before**
xcodebuild, instead of dying with "not a valid property list". Regenerate the
patches only when upstream rewrites the very lines the hunks target (see the
full guide's Upgrading section).

Full detail — every file, every hunk, every option — is in the companion
document **LiveContainer-FlekJIT-Fork-Guide** (docx/pdf).
